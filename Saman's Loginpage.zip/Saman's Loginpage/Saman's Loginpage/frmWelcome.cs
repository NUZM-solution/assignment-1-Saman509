﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace AttendanceMan
{
    public partial class frmWelcome : Form
    {
        private Button btnLogout;
        private Label labelWelcome;
        private GroupBox groupBoxWelcome;

        public frmWelcome()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.btnLogout = new Button();
            this.labelWelcome = new Label();
            this.groupBoxWelcome = new GroupBox();

            // 
            // Form Properties
            // 
            this.ClientSize = new Size(400, 300);
            this.BackColor = Color.Black; // Black background for the form
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // 
            // groupBoxWelcome
            // 
            this.groupBoxWelcome.Location = new Point(25, 20); // Adjusted position for better centering
            this.groupBoxWelcome.Size = new Size(350, 220); // Increased size to fit text properly
            this.groupBoxWelcome.BackColor = Color.Black; // Black background for GroupBox
            this.groupBoxWelcome.ForeColor = Color.White; // White text for GroupBox
            this.groupBoxWelcome.Text = "Welcome Page";

            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.Font = new Font("Arial", 14, FontStyle.Bold); // Slightly smaller font size
            this.labelWelcome.Location = new Point(50, 50); // Positioned centrally
            this.labelWelcome.ForeColor = Color.White; // White text
            this.labelWelcome.Text = "Welcome to the Application!";

            // 
            // btnLogout
            // 
            this.btnLogout.Location = new Point(125, 140); // Centered the button in the GroupBox
            this.btnLogout.Size = new Size(100, 30); // Increased size for better accessibility
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.BackColor = Color.Gray; // Gray button
            this.btnLogout.ForeColor = Color.White; // White text
            this.btnLogout.FlatStyle = FlatStyle.Flat;
            this.btnLogout.Click += new EventHandler(this.btnLogout_Click);

            // 
            // Add Controls to the GroupBox
            // 
            this.groupBoxWelcome.Controls.Add(this.labelWelcome);
            this.groupBoxWelcome.Controls.Add(this.btnLogout);

            // 
            // Add GroupBox to the Form
            // 
            this.Controls.Add(this.groupBoxWelcome);
            this.Load += new EventHandler(this.frmWelcome_Load);
        }

        private void frmWelcome_Load(object sender, EventArgs e)
        {
            // Additional initialization can go here
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            frmLogin loginForm = new frmLogin();
            loginForm.Show();
        }
    }
}
