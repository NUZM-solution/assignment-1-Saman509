namespace Saman_s_Table // Updated namespace to reflect the new name
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new SamanAsgharForm()); // Updated to reference the correct form
        }
    }
}
